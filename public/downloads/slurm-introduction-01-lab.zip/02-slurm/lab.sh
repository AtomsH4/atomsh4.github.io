#!/bin/bash
set -euo pipefail

lab_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
container=cluster-lab-slurm
image=cluster-lab-slurm:local
volume=cluster-lab-slurm-state

usage() {
    cat <<'HELP'
Usage: ./lab.sh COMMAND [ARGS...]
  up           Build if necessary, start the lab, and wait for readiness
  build        Build/rebuild the image for the current host user
  status       Show container health, nodes, queue, and recent accounting
  shell        Open a Bash shell as the normal user student
  exec CMD...  Execute a command as student in /workspace
  logs         Show recent service logs (Docker output)
  stop         Stop the lab, preserving its container and accounting
  down         Remove only this lab's container, preserving its state volume

Job scripts and outputs are in this directory, mounted at /workspace.
No host ports or privileged containers are used.
HELP
}

build() {
    if ! docker image inspect debian:trixie-slim >/dev/null 2>&1; then
        docker pull debian:trixie-slim
    fi
    docker build --build-arg LAB_UID="$(id -u)" --build-arg LAB_GID="$(id -g)" \
        -t "$image" "$lab_dir"
}

exists() {
    docker container inspect "$container" >/dev/null 2>&1
}

check_owner() {
    if exists && [ "$(docker inspect -f '{{index .Config.Labels "cluster-lab.project"}}' "$container")" != slurm ]; then
        echo "Container name $container is already used by another project." >&2
        exit 1
    fi
}

wait_ready() {
    for attempt in $(seq 1 150); do
        state=$(docker inspect -f '{{.State.Status}}' "$container")
        health=$(docker inspect -f '{{.State.Health.Status}}' "$container")
        if [ "$state" != running ]; then
            docker logs --tail 60 "$container"
            echo 'Lab stopped during startup.' >&2
            return 1
        fi
        if [ "$health" = healthy ]; then
            echo 'Slurm lab is ready. Run ./lab.sh shell or ./lab.sh status.'
            return 0
        fi
        sleep 1
    done
    docker logs --tail 60 "$container"
    echo 'Startup timed out. Inspect ./lab.sh logs.' >&2
    return 1
}

action=help
if [ "$#" -gt 0 ]; then action=$1; shift; fi
if [ "$action" = help ] || [ "$action" = --help ]; then usage; exit 0; fi
docker info >/dev/null
check_owner

case "$action" in
    build) build ;;
    up)
        mkdir -p "$lab_dir/logs" "$lab_dir/results"
        if exists; then
            docker start "$container" >/dev/null
        else
            if ! docker image inspect "$image" >/dev/null 2>&1; then build; fi
            docker run -d --init --name "$container" --hostname slurm-lab \
                --label cluster-lab.project=slurm --cpus=2 --memory=2g \
                --mount "type=bind,source=$lab_dir,target=/workspace" \
                --mount "type=volume,source=$volume,target=/var/lib/slurm-lab" \
                "$image" >/dev/null
        fi
        wait_ready
        ;;
    shell)
        exec docker exec -it -u student -w /workspace "$container" bash
        ;;
    exec)
        if [ "$#" -eq 0 ]; then usage; exit 2; fi
        exec docker exec -u student -w /workspace "$container" "$@"
        ;;
    status)
        docker ps -a --filter "name=^/$container$" --format 'table {{.Names}}\t{{.Status}}'
        docker exec -u student "$container" sinfo -N -l
        docker exec -u student "$container" squeue
        docker exec -u student "$container" sacct --starttime today \
            --format=JobID,JobName,State,ExitCode,Elapsed
        ;;
    logs) docker logs --tail 100 "$container" ;;
    stop) docker stop --timeout 30 "$container" ;;
    down)
        if exists; then
            docker stop --timeout 30 "$container" >/dev/null
            docker rm "$container"
        fi
        ;;
    *) usage; exit 2 ;;
esac
