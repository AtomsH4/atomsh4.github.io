# Slurm 入门学习（一）配套实验

配套文章：https://atomsh4.github.io/blog/slurm-introduction-01/

## 启动

需要可用的 Docker CLI 和 Docker daemon；macOS 可以使用已经配置好的 Colima。
实测环境为 macOS ARM64、Docker/Colima 和 Slurm 24.11.5。
实验使用两个 CPU，容器内存上限为 2 GiB；实测 Colima 虚拟机有约 3 GiB 内存。
首次构建需要下载 Debian 镜像和软件包。无需 Docker Compose。

解压后，在宿主机终端进入 02-slurm 目录：

```bash
./lab.sh up
./lab.sh status
./lab.sh shell
```

现在位于 Linux 容器内的 /workspace，以 student 身份执行 Slurm 命令。
输入 exit 返回宿主机终端。lab.sh 的管理命令在宿主机运行。

## 六个练习

下面这些命令在容器终端运行。逐个提交、记录返回的编号，并查询各自的状态与日志。

```bash
sbatch jobs/01-hello.slurm
sbatch jobs/02-python.slurm
sbatch jobs/03-fail.slurm
sbatch jobs/04-timeout.slurm
sbatch jobs/05-array.slurm
sbatch jobs/06-tasks.slurm
squeue -r -u student
sacct --array --starttime today --format=JobID,JobName,State,ExitCode,Elapsed
```

预期：Hello、Python、数组和 Tasks 正常完成；fail 故意失败；timeout 等待一分钟及调度检查时间后超时终止。
完整脚本在 jobs，Python 程序在 examples。logs 和 results 在宿主机上也可查看。
文章中的作业编号来自作者的运行记录，重新提交后编号会不同。

## 自动验证

也可在宿主机执行：

```bash
./lab.sh exec python3 -u verify.py
```

验证会实际提交作业，检查正常运行、结果文件、作业依赖、失败、任务编号、数组、排队取消及超时。
它需要几分钟，只取消本次验证提交的作业；报告写入 results/verification.json。

## 启停

这些命令在宿主机执行：

```bash
./lab.sh stop
./lab.sh up
./lab.sh logs
```

stop 保留容器、日志和数据库。down 删除本实验容器，但保留名为 cluster-lab-slurm-state 的状态卷。
修改 Dockerfile 或 config 后，依次运行 build、down、up 使用新配置。
停止之前先查看 squeue，确认不再需要运行中的作业。

## 实验范围

单节点 CPU 练习环境，没有 GPU，不能验证真实跨机器通信。
为适配无特权 Docker，未启用作业级 cgroup 硬限制；CPU 和内存申请用于调度。
容器整体受 Docker 资源限制。不要用这个环境测试内存耗尽或评价并行性能。
认证密钥和数据库密码在启动时生成，保存在运行环境中。
本压缩包仅包含源码和说明，没有包含作者的作业日志、结果或运行凭据。
