"""End-to-end exercises against the real local Slurm scheduler.

Run on the host: ./lab.sh exec python3 -u verify.py
Only jobs submitted by this run are cancelled during cleanup.
"""

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import time

TERMINAL = {
    "COMPLETED", "FAILED", "CANCELLED", "TIMEOUT", "NODE_FAIL",
    "OUT_OF_MEMORY", "PREEMPTED", "BOOT_FAIL", "DEADLINE",
}
submitted = []
report = {"started_at": datetime.now(timezone.utc).isoformat(), "checks": []}


def run(*command, check=True):
    result = subprocess.run(command, text=True, capture_output=True, timeout=15)
    if check and result.returncode:
        raise RuntimeError(f"{' '.join(command)}: {result.stderr.strip()}")
    return result.stdout.strip()


def submit(*args):
    job_id = run("sbatch", "--parsable", *args).split(";")[0]
    if not job_id.isdigit():
        raise RuntimeError(f"Unexpected job ID: {job_id!r}")
    submitted.append(job_id)
    return job_id


def records(job_id):
    output = run("sacct", "--array", "-X", "-nP", "-j", job_id,
                 "--format=JobID,State%30,ExitCode")
    rows = []
    for line in output.splitlines():
        fields = line.split("|")
        if len(fields) >= 3:
            rows.append({"job_id": fields[0], "state": fields[1].split()[0],
                         "exit_code": fields[2]})
    return rows


def finished(job_id, expected="COMPLETED", count=1, timeout=180):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        rows = records(job_id)
        if len(rows) == count and all(row["state"] in TERMINAL for row in rows):
            if any(row["state"] != expected for row in rows):
                raise RuntimeError(f"Expected {expected}, got {rows}")
            return rows
        time.sleep(1)
    raise TimeoutError(f"Job {job_id} did not reach {expected}: {records(job_id)}")


def queue_state(job_id, expected, timeout=30):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        state = run("squeue", "-h", "-j", job_id, "-o", "%T", check=False)
        if state == expected:
            return
        time.sleep(0.5)
    raise TimeoutError(f"Job {job_id} did not reach queue state {expected}")


def passed(name, rows):
    report["checks"].append({"name": name, "jobs": rows})
    print(f"[OK] {name}: {rows}", flush=True)


try:
    report["slurm_version"] = run("srun", "--version")
    report["user"] = run("whoami")
    if report["user"] != "student":
        raise RuntimeError("Run verification as the normal student user")

    hello = submit("jobs/01-hello.slurm")
    rows = finished(hello)
    hello_log = Path(f"logs/hello-{hello}.out").read_text()
    if "user=student" not in hello_log or "slurm-lab" not in hello_log:
        raise RuntimeError("Hello output is missing the user or compute hostname")
    passed("hello and log files", rows)

    python_job = submit("jobs/02-python.slurm")
    dependent = submit(f"--dependency=afterok:{python_job}", "jobs/01-hello.slurm")
    rows = finished(python_job)
    result = json.loads(Path(f"results/python-{python_job}.json").read_text())
    if result["result"] != result["expected"] or result["job_id"] != python_job:
        raise RuntimeError("Python output validation failed")
    passed("Python computation and result file", rows)
    passed("afterok job dependency", finished(dependent))

    failed = submit("jobs/03-fail.slurm")
    rows = finished(failed, expected="FAILED")
    if rows[0]["exit_code"] == "0:0":
        raise RuntimeError("An intentional failure returned a successful exit code")
    if "RuntimeError" not in Path(f"logs/fail-{failed}.err").read_text():
        raise RuntimeError("Failure traceback was not captured")
    passed("intentional failure and non-zero exit code", rows)

    tasks = submit("jobs/06-tasks.slurm")
    rows = finished(tasks)
    task_log = Path(f"logs/tasks-{tasks}.out").read_text()
    if "rank=0" not in task_log or "rank=1" not in task_log:
        raise RuntimeError("srun did not produce two task ranks")
    passed("two independently launched task ranks", rows)

    array = submit("jobs/05-array.slurm")
    rows = finished(array, count=6)
    for index in range(6):
        result = json.loads(Path(f"results/array-{array}-{index}.json").read_text())
        if result["array_task_id"] != str(index) or result["n"] != 100000 * (index + 1):
            raise RuntimeError(f"Array task {index} did not receive its own parameters")
    passed("six array tasks and independent output files", rows)

    common = ("--ntasks=1", "--cpus-per-task=2", "--mem=128M", "--time=00:02:00")
    holder = submit(*common, "--job-name=queue-holder", "--output=logs/%x-%j.out",
                    "--wrap=srun sleep 90")
    queue_state(holder, "RUNNING")
    waiting = submit(*common, "--job-name=queue-waiting", "--output=logs/%x-%j.out",
                     "--wrap=srun sleep 30")
    queue_state(waiting, "PENDING")
    run("scancel", waiting)
    rows = finished(waiting, expected="CANCELLED")
    run("scancel", holder)
    finished(holder, expected="CANCELLED")
    passed("resource contention, pending queue, and cancellation", rows)

    print("[RUN] timeout exercise: waiting for the one-minute time limit...", flush=True)
    timed_out = submit("jobs/04-timeout.slurm")
    passed("time-limit termination", finished(timed_out, expected="TIMEOUT"))
    report["status"] = "passed"
except Exception as error:
    report["status"] = "failed"
    report["error"] = str(error)
    raise
finally:
    if submitted:
        run("scancel", "--quiet", *submitted, check=False)
    report["finished_at"] = datetime.now(timezone.utc).isoformat()
    Path("results").mkdir(exist_ok=True)
    Path("results/verification.json").write_text(json.dumps(report, indent=2) + "\n")

print("All exercises passed. Report: results/verification.json", flush=True)
