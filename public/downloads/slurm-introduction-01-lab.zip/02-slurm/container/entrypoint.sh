#!/bin/bash
set -euo pipefail

state=/var/lib/slurm-lab
pids=()

shutdown() {
    trap - TERM INT EXIT
    rm -f /run/slurm-lab.ready
    # Stop compute/controller/accounting before the database and authentication.
    for ((i=${#pids[@]}-1; i>=0; i--)); do
        kill -TERM "${pids[i]}" 2>/dev/null || true
        wait "${pids[i]}" 2>/dev/null || true
    done
}
trap shutdown TERM INT EXIT

wait_for() {
    local label=$1
    shift
    for attempt in $(seq 1 90); do
        if "$@"; then return 0; fi
        for pid in "${pids[@]}"; do
            if ! kill -0 "$pid" 2>/dev/null; then
                echo "A daemon stopped while waiting for $label" >&2
                return 1
            fi
        done
        sleep 1
    done
    echo "Timed out waiting for $label" >&2
    return 1
}

install -d -m 0755 "$state" /var/log/slurm
install -d -o slurm -g slurm -m 0755 /run/slurm "$state/controller"
install -d -o root -g root -m 0755 "$state/node"
install -d -o mysql -g mysql -m 0755 /run/mysqld "$state/mysql"
install -d -o munge -g munge -m 0700 /etc/munge /var/lib/munge /var/log/munge
install -d -o munge -g munge -m 0755 /run/munge
chown slurm:slurm /var/log/slurm

if [ ! -s "$state/munge.key" ]; then
    (umask 077; head -c 1024 /dev/urandom > "$state/munge.key")
fi
install -o munge -g munge -m 0400 "$state/munge.key" /etc/munge/munge.key
runuser -u munge -- munged --foreground &
pids+=("$!")
wait_for munge bash -c 'munge -n | unmunge >/dev/null 2>&1'

if [ ! -d "$state/mysql/mysql" ]; then
    mariadb-install-db --user=mysql --datadir="$state/mysql" \
        --auth-root-authentication-method=socket --skip-test-db >/dev/null
fi
mariadbd --user=mysql --datadir="$state/mysql" \
    --socket=/run/mysqld/mysqld.sock --pid-file=/run/mysqld/mysqld.pid \
    --skip-networking --innodb-buffer-pool-size=64M --innodb-log-file-size=32M \
    --innodb-lock-wait-timeout=900 --max-allowed-packet=16M \
    --innodb-snapshot-isolation=OFF &
pids+=("$!")
wait_for mariadb mariadb-admin --socket=/run/mysqld/mysqld.sock ping --silent

if [ ! -s "$state/db-password" ]; then
    (umask 077; python3 -c 'import secrets; print(secrets.token_hex(24))' > "$state/db-password")
fi
db_password=$(cat "$state/db-password")
mariadb --socket=/run/mysqld/mysqld.sock <<SQL
CREATE DATABASE IF NOT EXISTS slurm_acct_db;
CREATE USER IF NOT EXISTS 'slurm'@'localhost' IDENTIFIED BY '$db_password';
ALTER USER 'slurm'@'localhost' IDENTIFIED BY '$db_password';
GRANT ALL PRIVILEGES ON slurm_acct_db.* TO 'slurm'@'localhost';
SQL

install -o slurm -g slurm -m 0600 /dev/null /etc/slurm/slurmdbd.conf
cat > /etc/slurm/slurmdbd.conf <<CONF
AuthType=auth/munge
DbdHost=slurm-lab
DbdPort=6819
SlurmUser=slurm
PidFile=/run/slurm/slurmdbd.pid
LogFile=/var/log/slurm/slurmdbd.log
DebugLevel=info
StorageType=accounting_storage/mysql
StorageHost=localhost
StorageUser=slurm
StoragePass=$db_password
StorageLoc=slurm_acct_db
CONF
unset db_password

slurmdbd -D &
pids+=("$!")
wait_for slurmdbd sacctmgr -nP show cluster
if ! sacctmgr -nP show cluster where name=lab format=Cluster | grep -qx 'lab'; then
    sacctmgr -i add cluster lab
fi
if ! sacctmgr -nP show account where name=lab format=Account | grep -qx 'lab'; then
    sacctmgr -i add account lab Description='Local teaching account' Organization=lab
fi
if ! sacctmgr -nP show user where name=student format=User | grep -qx 'student'; then
    sacctmgr -i add user student Account=lab DefaultAccount=lab
fi

slurmctld -D &
pids+=("$!")
wait_for slurmctld bash -c 'scontrol ping | grep -q "is UP"'
slurmd -D &
pids+=("$!")
wait_for slurmd bash -c 'sinfo -h -N -o "%T" | grep -Eq "^(idle|allocated|mixed)$"'
touch /run/slurm-lab.ready
echo 'Slurm lab ready: user=student partition=debug CPUs=2 memory=1536M'

set +e
wait -n "${pids[@]}"
exit_code=$?
set -e
echo "A Slurm lab daemon exited (status $exit_code); stopping the container." >&2
if [ "$exit_code" -eq 0 ]; then exit_code=1; fi
exit "$exit_code"
