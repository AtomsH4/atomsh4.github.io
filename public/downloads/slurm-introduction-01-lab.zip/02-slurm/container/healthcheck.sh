#!/bin/bash
set -euo pipefail
test -f /run/slurm-lab.ready
for daemon in munged mariadbd slurmdbd slurmctld slurmd; do
    pgrep -x "$daemon" >/dev/null
done
scontrol ping | grep -q 'is UP'
