"""Small standard-library workload; no NumPy, CUDA, or external data required."""

import argparse
import json
import os
from pathlib import Path
import socket
import time

parser = argparse.ArgumentParser()
parser.add_argument("--n", type=int, default=200_000)
parser.add_argument("--sleep", type=float, default=2)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
if args.n < 1 or args.sleep < 0:
    parser.error("n must be positive and sleep must be non-negative")

started = time.monotonic()
result = sum(i * i for i in range(args.n))
time.sleep(args.sleep)
record = {
    "job_id": os.environ.get("SLURM_JOB_ID"),
    "array_task_id": os.environ.get("SLURM_ARRAY_TASK_ID"),
    "hostname": socket.gethostname(),
    "n": args.n,
    "result": result,
    "expected": args.n * (args.n - 1) * (2 * args.n - 1) // 6,
    "elapsed_seconds": round(time.monotonic() - started, 3),
}
if record["result"] != record["expected"]:
    raise RuntimeError("calculation validation failed")
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record), flush=True)
